# Esquema de datos y seguridad Firebase

## Colecciones propuestas
- `users/{uid}`: `role`, `displayName`, `active`, `clientId`
- `clients/{clientId}`: `name`, `contactEmail`, `active`
- `orders/{orderId}`: `clientId`, `origin`, `destination`, `cargoDescription`, `status`, `createdAt`, `createdBy`
- `trips/{tripId}`: `orderIds`, `driverUid`, `vehicleId`, `status`, `plannedDeparture`, `actualDeparture`, `actualArrival`
- `tripLocations/{tripId}/points/{pointId}`: `lat`, `lng`, `recordedAt`
- `proofOfDelivery/{podId}`: `tripId`, `receivedBy`, `notes`, `photoPaths`, `signaturePath`, `recordedAt`

## Roles
- `admin`: gestión de usuarios y configuración.
- `operaciones`: crear órdenes y asignar viajes.
- `conductor`: ver viajes asignados y registrar hitos/entregas.
- `cliente`: consultar solo órdenes propias.

## Requisitos antes de desplegar
1. Configurar Firebase Authentication.
2. Configurar reglas de Firestore y Storage que validen usuario, rol y relación de cliente.
3. No usar reglas abiertas (`allow read, write: if true`).
4. Guardar imágenes y firmas en Storage con rutas y permisos por rol.
5. Solicitar permiso de ubicación y explicar claramente cuándo se comparte.
6. Recoger GPS solo para viajes activos y definir retención de ubicación.
7. Implementar almacenamiento local persistente, reintentos y resolución de conflictos para uso offline.
8. El portal de clientes será una aplicación web separada; no está incluido en el proyecto Android.
