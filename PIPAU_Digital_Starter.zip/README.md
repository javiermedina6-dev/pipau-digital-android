# PIPAU Digital — Starter de Android

Proyecto inicial Android (Kotlin + Jetpack Compose) para Transportes PIPAU.

## Qué incluye
- Interfaz en español y diseño provisional azul marino/azul.
- Panel de operaciones.
- Creación local de órdenes de demostración.
- Secciones iniciales de órdenes, viajes y entregas.
- Manifiesto Android y dependencias base para Firebase y ubicación.

## Estado real
Esta es una **base de desarrollo**, no una aplicación lista para producción. En esta versión:
- Las órdenes de ejemplo solo viven en memoria y se pierden al cerrar la app.
- Firebase no está conectado porque necesita un proyecto y su archivo `google-services.json`.
- Autenticación/roles, seguimiento GPS real, fotos/firmas POD y sincronización offline todavía deben implementarse y probarse.
- El portal web de clientes no está incluido en esta base Android.

## Requisitos
- Android Studio compatible con Android Gradle Plugin 8.7.x
- JDK 17
- Android SDK 35

## Compilar
1. Descomprime el ZIP y abre la carpeta del proyecto en Android Studio.
2. Espera la sincronización de Gradle.
3. Crea un proyecto Firebase en https://console.firebase.google.com/
4. Registra una app Android con el ID `cl.pipau.digital`.
5. Descarga `google-services.json` y colócalo en `app/google-services.json`.
6. Activa Firebase Authentication, Cloud Firestore y Storage.
7. Ejecuta en un dispositivo de prueba y usa Build > Build APK(s).

## Seguridad
Nunca uses reglas abiertas en Firestore/Storage ni guardes credenciales privadas en el APK. Antes de producción hay que implementar reglas que validen los roles y que cada cliente solo pueda ver sus propios datos.
