package cl.pipau.digital

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF102A43)
private val Blue = Color(0xFF1769AA)
private val Background = Color(0xFFF3F6FA)
private val Green = Color(0xFF23856D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PipauApp() }
    }
}

@Composable
fun PipauApp() {
    var page by remember { mutableStateOf("Inicio") }
    var showForm by remember { mutableStateOf(false) }
    var client by remember { mutableStateOf("") }
    var origin by remember { mutableStateOf("") }
    var destination by remember { mutableStateOf("") }
    var orders by remember { mutableStateOf(listOf("ORD-0001 · Concepción → Santiago · Pendiente")) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Green, background = Background)) {
        Scaffold(
            containerColor = Background,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Navy).padding(20.dp)) {
                    Text("PIPAU DIGITAL", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("Gestión inteligente de transporte", color = Color(0xFFD7E6F5), fontSize = 12.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Inicio", "Órdenes", "Viajes", "Entregas").forEach { label ->
                        NavigationBarItem(
                            selected = page == label,
                            onClick = { page = label },
                            icon = {
                                Icon(when (label) {
                                    "Órdenes" -> Icons.Default.ReceiptLong
                                    "Viajes" -> Icons.Default.LocalShipping
                                    "Entregas" -> Icons.Default.TaskAlt
                                    else -> Icons.Default.Dashboard
                                }, contentDescription = label)
                            },
                            label = { Text(label) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (page == "Órdenes") FloatingActionButton(onClick = { showForm = true }, containerColor = Blue, contentColor = Color.White) {
                    Icon(Icons.Default.Add, contentDescription = "Nueva orden")
                }
            }
        ) { padding ->
            when (page) {
                "Inicio" -> Dashboard(Modifier.padding(padding), orders.size)
                "Órdenes" -> OrdersScreen(Modifier.padding(padding), orders) { showForm = true }
                "Viajes" -> PlaceholderScreen(Modifier.padding(padding), "Viajes", "Asignación de órdenes, conductores, vehículos y estados del viaje.")
                "Entregas" -> PlaceholderScreen(Modifier.padding(padding), "Pruebas de entrega", "Preparado para registrar recepción, fotos, firma y fecha/hora.")
            }
        }

        if (showForm) AlertDialog(
            onDismissRequest = { showForm = false },
            title = { Text("Nueva orden de transporte") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(client, { client = it }, label = { Text("Cliente / referencia") }, singleLine = true)
                    OutlinedTextField(origin, { origin = it }, label = { Text("Origen") }, singleLine = true)
                    OutlinedTextField(destination, { destination = it }, label = { Text("Destino") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (client.isNotBlank() && origin.isNotBlank() && destination.isNotBlank()) {
                        val id = orders.size + 1
                        orders = orders + "ORD-%04d · %s → %s · Pendiente · %s".format(id, origin, destination, client)
                        client = ""; origin = ""; destination = ""; showForm = false
                    }
                }) { Text("Guardar") }
            },
            dismissButton = { TextButton(onClick = { showForm = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun Dashboard(modifier: Modifier, count: Int) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Panel de operaciones", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text("Resumen · Versión inicial", color = Color.Gray)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Metric("Órdenes", count.toString(), Icons.Default.ReceiptLong, Modifier.weight(1f))
                Metric("Viajes activos", "0", Icons.Default.LocalShipping, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Metric("Entregas", "0", Icons.Default.TaskAlt, Modifier.weight(1f))
                Metric("Conductores", "0", Icons.Default.Badge, Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Próximas funciones", fontWeight = FontWeight.Bold, color = Navy)
                    Text("• Inicio de sesión y permisos por rol")
                    Text("• Datos sincronizados en la nube")
                    Text("• GPS y pruebas de entrega")
                    Text("• Trabajo sin conexión")
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE4F3EE))) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudDone, contentDescription = null, tint = Green)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Conexión a la nube pendiente", color = Navy, fontWeight = FontWeight.SemiBold)
                        Text("Esta versión usa datos locales de demostración.", color = Navy, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun Metric(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Icon(icon, contentDescription = null, tint = Blue)
            Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text(title, fontSize = 13.sp, color = Color.Gray)
        }
    }
}

@Composable
private fun OrdersScreen(modifier: Modifier, orders: List<String>, onNew: () -> Unit) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Órdenes de transporte", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("Crea y consulta solicitudes de transporte.", color = Color.Gray)
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp)); Text("Nueva orden")
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(orders) { order ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Inventory2, contentDescription = null, tint = Blue)
                        Spacer(Modifier.width(12.dp)); Text(order, color = Navy)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaceholderScreen(modifier: Modifier, title: String, description: String) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text(description, color = Color.Gray)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Construction, contentDescription = null, tint = Blue)
                Text("Módulo en desarrollo", fontWeight = FontWeight.SemiBold)
                Text("Esta pantalla es una base visual; requiere conexión a servicios y pruebas para funcionar en producción.")
            }
        }
    }
}
